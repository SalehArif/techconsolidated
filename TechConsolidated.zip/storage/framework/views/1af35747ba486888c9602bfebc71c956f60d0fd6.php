
<?php $__env->startSection('title'); ?>Order Status <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid main pad">
        <h1>Order Status</h1>
        <p>Order# <?php echo e($order_id); ?></p>
        <p>Your Order will be Delivered by <?php echo e($month); ?> <?php echo e($day+1); ?>-<?php echo e($day+3); ?></p>
        <ul class="list-group">
            <li class="list-group-item list-group-item-primary"><i class="fa fa-check"></i><?php echo e($month); ?> <?php echo e($day); ?> : Processing Order</li>
            <li class="list-group-item list-group-item-secondary"><?php echo e($month); ?> <?php echo e($day+1); ?> : Packaged Order</li>
            <li class="list-group-item list-group-item-secondary"><?php echo e($month); ?> <?php echo e($day+2); ?> : Shipped</li>
            <li class="list-group-item list-group-item-secondary"><?php echo e($month); ?> <?php echo e($day+3); ?> : Delivered</li>
        </ul>
        <br>
        <a href="receipt?id=<?php echo e($order_id); ?>" class="btn btn-primary col-4 offset-4">Order Receipt</a>
    </div>
    <script>
        const li =  document.querySelectorAll('.list-group-item');
        const month = new Date().getMonth()+1;
        const day = new Date().getDate();
        const months = {1: "January", 2: "Febuary", 3:"March",4:"April",5:"May", 6:"June", 7:"July",8: "August",9:"September",10:"October",11:"November",12:"December"}
        li.forEach((item,index)=>{
            //text.split(' ') get first2 index for date and compare
            let text = item.innerText
            let dates = text.split(" ",2)
            console.log(text)
            console.log(dates)
            if(dates[0]==months[month] && dates[1]==day){
            item.className = "list-group-item list-group-item-primary";
            item.innerHTML = `<i class="fa fa-check"></i>`+text
            }
        })

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DCS\Desktop\TechConsolidated\resources\views/order-status.blade.php ENDPATH**/ ?>